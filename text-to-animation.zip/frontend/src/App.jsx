import React, {useState} from 'react'

export default function App(){
  const [text,setText]=useState('');
  const [voice,setVoice]=useState('alloy');
  const [style,setStyle]=useState('talking_head');
  const [music,setMusic]=useState('mellow');
  const [duration,setDuration]=useState(8);
  const [status,setStatus]=useState('');
  const [jobId,setJobId]=useState(null);
  const [previewUrl,setPreviewUrl]=useState(null);

  async function generate(){
    setStatus('Submitting...');
    try{
      const res=await fetch('/api/generate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text,voice,style,music,duration})});
      const j=await res.json();
      if(j.jobId){ setJobId(j.jobId); setStatus('Job submitted: '+j.jobId); }
      else if(j.outputUrl){ setPreviewUrl(j.outputUrl); setStatus('Ready'); }
      else setStatus('Unexpected response');
    }catch(e){ setStatus('Error: '+e.message) }
  }

  async function check(){
    if(!jobId){ setStatus('No job id'); return }
    setStatus('Checking...');
    const res=await fetch(`/api/status/${jobId}`);
    const j=await res.json();
    setStatus('Status: '+j.status);
    if(j.status==='completed' || j.status==='succeeded' || j.status==='done') setPreviewUrl(j.outputUrl);
  }

  return (
    <div style={{maxWidth:900,margin:'auto',padding:16,fontFamily:'sans-serif'}}>
      <h1>Text → Animation (API-based Starter)</h1>
      <textarea value={text} onChange={e=>setText(e.target.value)} rows={8} style={{width:'100%'}} placeholder="Enter script or prompt..." />
      <div style={{display:'flex',gap:8,marginTop:8}}>
        <select value={voice} onChange={e=>setVoice(e.target.value)}>
          <option value="alloy">Alloy (default)</option>
          <option value="verse">Verse</option>
        </select>
        <select value={style} onChange={e=>setStyle(e.target.value)}>
          <option value="talking_head">Talking head</option>
          <option value="kinetic_text">Kinetic text</option>
        </select>
        <select value={music} onChange={e=>setMusic(e.target.value)}>
          <option value="mellow">Mellow</option>
          <option value="upbeat">Upbeat</option>
          <option value="none">No music</option>
        </select>
        <input type="number" value={duration} onChange={e=>setDuration(Number(e.target.value))} style={{width:80}} />
      </div>
      <div style={{marginTop:8}}>
        <button onClick={generate}>Generate</button>
        <button onClick={check} style={{marginLeft:8}}>Check</button>
      </div>
      <div style={{marginTop:12}}><strong>Status:</strong> {status}</div>
      {previewUrl && <div style={{marginTop:12}}><video src={previewUrl} controls style={{width:'100%'}}/></div>}
      <p style={{marginTop:12,fontSize:13,color:'#555'}}>Notes: this UI talks to server /api endpoints. Run server & worker then use this frontend (vite or build into server/public).</p>
    </div>
  )
}
