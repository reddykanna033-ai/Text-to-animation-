require('dotenv').config();
const path = require('path');
const fs = require('fs');
const { queue } = require('./jobQueue');
const { generateTTS } = require('./tts');
const { generateImage } = require('./imageGen');
const { composeVideo } = require('./composer');

queue.process('generate', async (job) => {
  const { jobId, text, voice, style, music, duration } = job.data;
  const workDir = path.join(__dirname, '..', 'media', jobId);
  fs.mkdirSync(workDir, { recursive: true });

  // 1) TTS
  const ttsPath = path.join(workDir, 'tts.mp3');
  console.log('Generating TTS...');
  await generateTTS(text, voice, ttsPath);

  // 2) Image generation
  console.log('Generating image...');
  const prompt = text.length > 240 ? text.slice(0, 240) : text;
  const visualAssets = await generateImage({ prompt, workDir });

  // 3) Compose final video (FFmpeg)
  console.log('Composing video...');
  const out = path.join(__dirname, '..', 'media', `${jobId}.mp4`);
  await composeVideo({ visualAssets, ttsPath, music, out, duration: duration || 8 });

  console.log('Done:', out);
  return { outputUrl: `/media/${path.basename(out)}` };
});

console.log('Worker running');
