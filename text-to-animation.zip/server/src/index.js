require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const { queue } = require('./jobQueue');
const { v4: uuidv4 } = require('uuid');

const app = express();
app.use(bodyParser.json());

// Serve frontend (optional) if built into frontend/dist
app.use(express.static(path.join(__dirname, '../../frontend/dist')));

// POST /api/generate
app.post('/api/generate', async (req, res) => {
  const { text, voice, style, music, duration } = req.body;
  if (!text) return res.status(400).json({ error: 'text required' });
  const jobId = uuidv4();
  // Add job with jobId set so we can query by id
  const job = await queue.add('generate', { jobId, text, voice, style, music, duration }, { jobId });
  return res.json({ jobId: job.id });
});

// GET /api/status/:id
app.get('/api/status/:id', async (req, res) => {
  const id = req.params.id;
  const job = await queue.getJob(id);
  if (!job) return res.json({ status: 'not_found' });
  const state = await job.getState();
  const ret = job.returnvalue || {};
  return res.json({ status: state, ...ret });
});

// Serve media files
app.get('/media/:file', (req, res) => {
  const f = path.join(__dirname, '..', 'media', req.params.file);
  res.sendFile(f);
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log('Server listening on', port));
