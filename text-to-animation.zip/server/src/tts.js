const fs = require('fs');
const path = require('path');
const OpenAI = require('openai');
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

async function generateTTS(text, voice = 'alloy', outPath) {
  // Uses OpenAI TTS via the SDK. Depending on SDK version, method signatures may vary.
  // This implementation uses audio.speech.create as an example; adjust if your SDK differs.
  const res = await client.audio.speech.create({
    model: 'gpt-4o-mini-tts',
    voice,
    input: text
  });

  if (res.arrayBuffer) {
    const buffer = Buffer.from(await res.arrayBuffer());
    fs.writeFileSync(outPath, buffer);
    return outPath;
  }
  return new Promise((resolve, reject) => {
    const stream = res;
    const out = fs.createWriteStream(outPath);
    stream.pipe(out);
    stream.on('end', () => resolve(outPath));
    stream.on('error', reject);
  });
}

module.exports = { generateTTS };
