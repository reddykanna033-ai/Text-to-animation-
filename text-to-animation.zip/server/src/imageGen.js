const fetch = require('node-fetch');
const fs = require('fs');
const path = require('path');

async function generateImage({ prompt, width = 1280, height = 720, workDir }) {
  const token = process.env.REPLICATE_API_TOKEN;
  if (!token) throw new Error('REPLICATE_API_TOKEN missing');

  const body = {
    version: process.env.REPLICATE_SD_VERSION || 'latest',
    input: {
      prompt,
      width,
      height
    }
  };

  const resp = await fetch('https://api.replicate.com/v1/predictions', {
    method: 'POST',
    headers: {
      Authorization: `Token ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(body)
  });

  if (!resp.ok) {
    const txt = await resp.text();
    throw new Error('Replicate API error: ' + txt);
  }

  const job = await resp.json();
  let status = job.status;
  let result = job;
  const getUrl = `https://api.replicate.com/v1/predictions/${job.id}`;
  while (status === 'starting' || status === 'processing') {
    await new Promise(r => setTimeout(r, 1500));
    const r = await fetch(getUrl, { headers: { Authorization: `Token ${token}` }});
    result = await r.json();
    status = result.status;
  }

  if (status !== 'succeeded') throw new Error('Image job failed: ' + JSON.stringify(result));
  const outUrl = Array.isArray(result.output) ? result.output[0] : result.output;
  const imgResp = await fetch(outUrl);
  const ext = (imgResp.headers.get('content-type') || '').includes('png') ? 'png' : 'jpg';
  const outPath = path.join(workDir, `scene.${ext}`);
  const buffer = Buffer.from(await imgResp.arrayBuffer());
  fs.writeFileSync(outPath, buffer);
  return { type: 'image', path: outPath };
}

module.exports = { generateImage };
