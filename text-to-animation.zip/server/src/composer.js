const cp = require('child_process');
const path = require('path');

function getMusicPath(tag) {
  const map = {
    mellow: path.resolve(__dirname, '..', 'media', 'music', 'mellow.mp3'),
    upbeat: path.resolve(__dirname, '..', 'media', 'music', 'upbeat.mp3')
  };
  return map[tag] || null;
}

async function composeVideo({ visualAssets, ttsPath, music, out, duration = 8 }) {
  const tmpVid = out.replace('.mp4', '.tmp.mp4');

  if (visualAssets.type === 'image') {
    const img = visualAssets.path;
    const cmd = `ffmpeg -y -loop 1 -i "${img}" -c:v libx264 -t ${duration} -vf "scale=1280:720,zoompan=z='if(lte(pzoom,1.0),1.0,pzoom+0.0007)':d=125" -pix_fmt yuv420p "${tmpVid}"`;
    cp.execSync(cmd, { stdio: 'inherit' });
  } else if (visualAssets.type === 'video') {
    const cmd = `ffmpeg -y -i "${visualAssets.path}" -t ${duration} -c:v libx264 -pix_fmt yuv420p "${tmpVid}"`;
    cp.execSync(cmd, { stdio: 'inherit' });
  } else {
    throw new Error('Unknown visualAssets type');
  }

  const musicPath = music === 'none' ? null : getMusicPath(music);
  if (!musicPath) {
    const cmd2 = `ffmpeg -y -i "${tmpVid}" -i "${ttsPath}" -c:v copy -c:a aac -map 0:v:0 -map 1:a:0 -shortest "${out}"`;
    cp.execSync(cmd2, { stdio: 'inherit' });
    return out;
  }

  const cmd3 = `ffmpeg -y -i "${tmpVid}" -i "${musicPath}" -i "${ttsPath}" -filter_complex "[1:a]volume=0.25[a1];[2:a]volume=1[a2];[a1][a2]amix=inputs=2:duration=shortest:dropout_transition=2[aout]" -map 0:v -map "[aout]" -c:v libx264 -c:a aac -shortest "${out}"`;
  cp.execSync(cmd3, { stdio: 'inherit' });
  return out;
}

module.exports = { composeVideo };
